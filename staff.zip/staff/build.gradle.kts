plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.multikore.korepay.staff"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.multikore.korepay.staff"
        minSdk = 26          // CameraX-free capture via ACTION_IMAGE_CAPTURE works from 21+, 26 keeps the code simple (no legacy storage permission branches)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "APP_NAME", "\"KorePay Field Staff\"")
    }

    buildTypes {
        debug {
            buildConfigField("boolean", "ALLOW_HTTP", "true")
        }
        release {
            buildConfigField("boolean", "ALLOW_HTTP", "false")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true; viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // QR rendering only (no server/decoding use). A well-established, small, dependency-free library.
    implementation("com.google.zxing:core:3.5.3")
    // On-device OCR for CNIC text; image processing stays on the staff phone.
    implementation("com.google.android.gms:play-services-mlkit-text-recognition:19.0.1")
    testImplementation("junit:junit:4.13.2")
}
