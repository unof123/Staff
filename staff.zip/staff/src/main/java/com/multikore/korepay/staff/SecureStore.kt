package com.multikore.korepay.staff

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypted local storage for the staff member's bearer token, via an Android Keystore key. Fails closed. */
object SecureStore {
    private const val ALIAS = "korepay_staff_store_v1"
    private const val PREFS = "korepay_staff_secure"
    private const val TRANSFORM = "AES/GCM/NoPadding"

    @Volatile var lastError: String? = null
        private set

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return gen.generateKey()
    }

    @Synchronized
    fun put(c: Context, name: String, value: String): Boolean = try {
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ct = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val enc = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
        prefs(c).edit().putString(name, enc).commit().also { if (it) lastError = null }
    } catch (e: Exception) {
        lastError = "Secure storage unavailable (${e.javaClass.simpleName})"; false
    }

    @Synchronized
    fun get(c: Context, name: String): String? {
        val enc = prefs(c).getString(name, null) ?: return null
        return try {
            val (iv, ct) = enc.split(":", limit = 2).let { Base64.decode(it[0], Base64.NO_WRAP) to Base64.decode(it[1], Base64.NO_WRAP) }
            val cipher = Cipher.getInstance(TRANSFORM)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ct), Charsets.UTF_8).also { lastError = null }
        } catch (e: Exception) {
            lastError = "Secure storage unreadable (${e.javaClass.simpleName})"; null
        }
    }

    @Synchronized fun remove(c: Context, name: String) { prefs(c).edit().remove(name).commit() }
    @Synchronized fun clearAll(c: Context) { prefs(c).edit().clear().commit() }
}
