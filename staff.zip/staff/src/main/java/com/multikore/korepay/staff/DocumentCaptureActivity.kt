package com.multikore.korepay.staff

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.multikore.korepay.staff.databinding.ActivityDocumentCaptureBinding
import java.io.File
import java.util.concurrent.Executors

/**
 * Captures CNIC front/back and a selfie with the device camera and uploads each immediately
 * (encrypted at rest on the server; see backend/src/services/documents.ts). No gallery picker is
 * offered on purpose, so the photo is always a fresh capture of the document in hand.
 */
class DocumentCaptureActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDocumentCaptureBinding
    private val io = Executors.newSingleThreadExecutor()
    private var pendingKind: String? = null
    private var pendingUri: Uri? = null
    private val uploaded = mutableSetOf<String>()

    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingKind?.let { launchCamera(it) } else Toast.makeText(this, "Camera permission is required to capture a photo", Toast.LENGTH_LONG).show()
    }
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val kind = pendingKind; val uri = pendingUri
        if (ok && kind != null && uri != null) upload(kind, uri) else statusFor(kind)?.text = "Not captured"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDocumentCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (WizardState.customerId == null) { finish(); return }

        // CNIC front/back were captured once on the customer form and uploaded with OCR data.
        binding.imgCnicFront.visibility = View.GONE
        binding.btnCnicFront.visibility = View.GONE
        binding.tvCnicFrontStatus.text = "CNIC front uploaded ✓"
        binding.imgCnicBack.visibility = View.GONE
        binding.btnCnicBack.visibility = View.GONE
        binding.tvCnicBackStatus.text = "CNIC back uploaded ✓"
        uploaded.add("cnic_front"); uploaded.add("cnic_back")
        binding.btnSelfie.setOnClickListener { capture("selfie") }
        binding.btnNext.setOnClickListener { goNext() }
        binding.btnSkip.visibility = View.GONE
    }

    private fun imageFor(kind: String): ImageView = when (kind) { "cnic_front" -> binding.imgCnicFront; "cnic_back" -> binding.imgCnicBack; else -> binding.imgSelfie }
    private fun statusFor(kind: String?): TextView? = when (kind) { "cnic_front" -> binding.tvCnicFrontStatus; "cnic_back" -> binding.tvCnicBackStatus; "selfie" -> binding.tvSelfieStatus; else -> null }

    private fun capture(kind: String) {
        pendingKind = kind
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestCamera.launch(Manifest.permission.CAMERA)
        } else {
            launchCamera(kind)
        }
    }

    private fun launchCamera(kind: String) {
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        val file = File(dir, "$kind-${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "com.multikore.korepay.staff.fileprovider", file)
        pendingUri = uri
        takePicture.launch(uri)
    }

    private fun upload(kind: String, uri: Uri) {
        statusFor(kind)?.text = "Uploading…"
        io.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size > 10 * 1024 * 1024) throw ApiException(413, "too_large", "Photo is too large")
                apiFor(this).uploadDocument("/api/v1/admin/customers/${WizardState.customerId}/documents", kind, bytes, "$kind.jpg", "image/jpeg")
                uploaded += kind
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                runOnUiThread { imageFor(kind).setImageBitmap(bmp); statusFor(kind)?.text = "Uploaded ✓" }
            } catch (e: ApiException) {
                runOnUiThread { statusFor(kind)?.text = "Failed: ${e.message}" }
            } catch (e: Exception) {
                runOnUiThread { statusFor(kind)?.text = "Failed: ${e.javaClass.simpleName}" }
            }
        }
    }

    private fun goNext() {
        if (!uploaded.contains("selfie")) {
            Toast.makeText(this, "Capture and upload the customer selfie before continuing.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(Intent(this, PhoneDetailsActivity::class.java))
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
