package com.multikore.korepay.staff

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.multikore.korepay.staff.databinding.ActivityPlanFormBinding
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class PlanFormActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPlanFormBinding
    private val io = Executors.newSingleThreadExecutor()
    private val frequencies = listOf("monthly" to "Monthly", "biweekly" to "Every 2 weeks", "weekly" to "Weekly")
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private var dueDate: Calendar = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 30) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlanFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (WizardState.customerId == null) { finish(); return }

        binding.spFrequency.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, frequencies.map { it.second })
        renderDate()
        binding.btnChangeDate.setOnClickListener { pickDate() }
        binding.btnNext.setOnClickListener { submit() }
        binding.btnSkip.visibility = View.GONE
        binding.btnNext.text = "Submit for Approval"
    }

    private fun renderDate() { binding.tvDueDate.text = "First due date: ${fmt.format(dueDate.time)}" }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d -> dueDate.set(y, m, d); renderDate() }, dueDate.get(Calendar.YEAR), dueDate.get(Calendar.MONTH), dueDate.get(Calendar.DAY_OF_MONTH))
            .apply { datePicker.minDate = System.currentTimeMillis() }.show()
    }

    private fun showError(m: String) { binding.tvError.text = m; binding.tvError.visibility = View.VISIBLE }

    private fun submit() {
        val price = Money.toMinor(binding.etPrice.text.toString())
        val down = if (binding.etDown.text.toString().isBlank()) 0 else Money.toMinor(binding.etDown.text.toString())
        val count = binding.etCount.text.toString().toIntOrNull()
        if (price == null || price <= 0) { showError("Enter a valid total price"); return }
        if (down == null) { showError("Enter a valid down payment (or leave blank for none)"); return }
        if (down >= price) { showError("Down payment must be less than the total price"); return }
        if (count == null || count < 1 || count > 60) { showError("Enter 1 to 60 installments"); return }

        binding.btnNext.isEnabled = false
        binding.tvError.visibility = View.GONE
        io.execute {
            try {
                val body = JSONObject()
                    .put("customer_id", WizardState.customerId)
                    .put("total_price_minor", price)
                    .put("down_payment_minor", down)
                    .put("installments_count", count)
                    .put("frequency", frequencies[binding.spFrequency.selectedItemPosition].first)
                    .put("first_due_date", fmt.format(dueDate.time))
                if (WizardState.planId == null) {
                    val res = apiFor(this).post("/api/v1/admin/plans", body)
                    WizardState.planId = res.getJSONObject("plan").getString("id")
                }
                apiFor(this).post("/api/v1/admin/customers/${WizardState.customerId}/submit", JSONObject())
                runOnUiThread { startActivity(Intent(this, ApprovalStatusActivity::class.java)) }
            } catch (e: ApiException) {
                runOnUiThread { binding.btnNext.isEnabled = true; showError(e.message ?: "Could not save the plan") }
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
