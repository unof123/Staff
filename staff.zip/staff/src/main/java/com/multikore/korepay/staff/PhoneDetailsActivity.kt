package com.multikore.korepay.staff

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.multikore.korepay.staff.databinding.ActivityPhoneDetailsBinding
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class PhoneDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPhoneDetailsBinding
    private val io = Executors.newSingleThreadExecutor()
    private var photoUri: Uri? = null
    private var phoneRecordSaved = false
    private var stickerUploaded = false
    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) launchBoxCamera() else binding.tvBoxOcrStatus.text = "Camera permission required; enter details manually." }
    private val takeBoxPhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = photoUri
        if (ok && uri != null) runBoxOcr(uri) else binding.tvBoxOcrStatus.text = "Box photo was not captured."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhoneDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (WizardState.customerId == null) { finish(); return }
        binding.btnNext.setOnClickListener { submit() }
        binding.btnScanBox.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestCamera.launch(Manifest.permission.CAMERA) else launchBoxCamera()
        }
    }

    private fun launchBoxCamera() {
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        val file = File(dir, "phone-box-${System.currentTimeMillis()}.jpg")
        photoUri = FileProvider.getUriForFile(this, "com.multikore.korepay.staff.fileprovider", file)
        takeBoxPhoto.launch(photoUri!!)
    }

    private fun runBoxOcr(uri: Uri) {
        binding.tvBoxOcrStatus.text = "Reading sticker…"
        try {
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { result ->
                    val text = result.text.map { ch -> when (ch) { in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar(); in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar(); else -> ch } }.joinToString("")
                    val digits = Regex("(?<!\\d)(\\d{15})(?!\\d)").findAll(text).map { it.value }.distinct().toList()
                    if (digits.isNotEmpty()) binding.etImei.setText(digits[0])
                    if (digits.size > 1) binding.etImei2.setText(digits[1])
                    val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
                    val brand = listOf("Infinix", "Tecno", "Vivo", "Redmi", "Xiaomi", "OPPO", "Realme", "HONOR", "itel", "Samsung").firstOrNull { b -> text.contains(b, true) }
                    brand?.let { binding.etBrand.setText(it) }
                    val modelLine = lines.firstOrNull { line -> line.contains(Regex("(?i)model|model name|product name")) }
                    if (modelLine != null) {
                        val candidate = modelLine.substringAfter(':', modelLine).trim()
                        if (candidate.length in 2..80) binding.etModel.setText(candidate)
                    } else {
                        lines.firstOrNull { it.matches(Regex("(?i).*(X[0-9]{2,}|NOTE ?[0-9A-Z]+|HOT ?[0-9A-Z]+|SPARK ?[0-9A-Z]+|A[0-9]{2,}).*")) }
                            ?.let { binding.etModel.setText(it.take(80)) }
                    }
                    val serialLine = lines.firstOrNull { it.contains("S/N", true) || it.contains("Serial", true) }
                    serialLine?.substringAfter(':', "")?.trim()?.takeIf { it.isNotBlank() }?.let { binding.etSerial.setText(it.take(80)) }
                    binding.tvBoxOcrStatus.text = if (text.isBlank()) "No text found. Enter the details manually." else "OCR finished. Verify brand, model and complete 15-digit IMEI before continuing."
                }
                .addOnFailureListener { binding.tvBoxOcrStatus.text = "OCR failed. Enter details manually." }
        } catch (_: Exception) { binding.tvBoxOcrStatus.text = "Could not read photo. Enter details manually." }
    }

    private fun showError(m: String) { binding.tvError.text = m; binding.tvError.visibility = View.VISIBLE }

    private fun submit() {
        val brand = binding.etBrand.text.toString().trim()
        val model = binding.etModel.text.toString().trim()
        val imei = binding.etImei.text.toString().trim().filter { it.isDigit() }
        val imei2 = binding.etImei2.text.toString().trim().filter { it.isDigit() }
        if (photoUri == null) { showError("Capture the phone box IMEI sticker photo first."); return }
        if (brand.isEmpty() || model.isEmpty()) { showError("Enter/verify the phone brand and model from the box sticker"); return }
        if (!Imei.isValid(imei)) { showError("That IMEI does not look right. Re-check all 15 digits on the box."); return }
        if (imei2.isNotEmpty() && !Imei.isValid(imei2)) { showError("IMEI 2 does not look right"); return }
        binding.btnNext.isEnabled = false; binding.tvError.visibility = View.GONE
        io.execute {
            try {
                val body = JSONObject().put("customer_id", WizardState.customerId).put("brand", brand).put("model", model).put("imei", imei)
                if (imei2.isNotEmpty()) body.put("imei2", imei2)
                val serial = binding.etSerial.text.toString().trim(); if (serial.isNotEmpty()) body.put("serial", serial)
                if (!phoneRecordSaved) {
                    apiFor(this).post("/api/v1/admin/phone-records", body)
                    phoneRecordSaved = true
                }
                val sticker = photoUri
                if (sticker != null && !stickerUploaded) {
                    val bytes = contentResolver.openInputStream(sticker)?.use { it.readBytes() } ?: throw ApiException(0, "photo_read", "Could not read box sticker photo")
                    if (bytes.size > 10 * 1024 * 1024) throw ApiException(413, "too_large", "Box sticker photo is too large")
                    apiFor(this).uploadDocument("/api/v1/admin/customers/${WizardState.customerId}/documents", "box_sticker", bytes, "box-sticker.jpg", "image/jpeg")
                    stickerUploaded = true
                }
                runOnUiThread { startActivity(Intent(this, PlanFormActivity::class.java)) }
            } catch (e: ApiException) { runOnUiThread { binding.btnNext.isEnabled = true; showError(e.message ?: "Could not save the phone details") } }
        }
    }
    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
