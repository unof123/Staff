package com.multikore.korepay.staff

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.multikore.korepay.staff.databinding.ActivityLoginBinding
import org.json.JSONObject
import java.util.concurrent.Executors

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Session.isSignedIn(this) && Session.serverUrl(this) != null) {
            startActivity(Intent(this, HomeActivity::class.java)); finish(); return
        }

        binding.tvServer.text = "Server: ${Session.serverUrl(this) ?: "not set"}"
        binding.btnServer.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    override fun onResume() {
        super.onResume()
        binding.tvServer.text = "Server: ${Session.serverUrl(this) ?: "not set"}"
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = View.VISIBLE
    }

    private fun attemptLogin() {
        val server = Session.serverUrl(this)
        if (server == null) { showError("Set the server address first (below)"); return }
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()
        if (email.isEmpty() || password.isEmpty()) { showError("Enter your email and password"); return }
        binding.btnLogin.isEnabled = false
        binding.tvError.visibility = View.GONE
        io.execute {
            try {
                val body = JSONObject().put("email", email).put("password", password).put("device_label", android.os.Build.MODEL)
                val res = ApiClient(server, null).post("/api/v1/admin/staff-auth/login", body)
                val user = res.getJSONObject("user")
                val perms = (0 until res.getJSONArray("permissions").length()).map { res.getJSONArray("permissions").getString(it) }
                val ok = Session.save(this, res.getString("token"), user.getString("name"), user.getString("email"), user.getString("role"), perms)
                runOnUiThread {
                    binding.btnLogin.isEnabled = true
                    if (!ok) { showError(SecureStore.lastError ?: "Could not save your sign-in securely on this phone"); return@runOnUiThread }
                    startActivity(Intent(this, HomeActivity::class.java)); finish()
                }
            } catch (e: ApiException) {
                runOnUiThread { binding.btnLogin.isEnabled = true; showError(e.message ?: "Sign-in failed") }
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
