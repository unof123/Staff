package com.multikore.korepay.staff

import java.net.URI

/** Validates the server address a manager types into Settings. Pure logic, no Android dependency. */
object ServerUrl {
    sealed class Result {
        data class Ok(val url: String) : Result()
        data class Invalid(val reason: String) : Result()
    }

    fun validate(raw: String?, allowHttp: Boolean): Result {
        val s = raw?.trim().orEmpty()
        if (s.isEmpty()) return Result.Invalid("Enter a server address")
        if (s.length > 200) return Result.Invalid("That address is too long")
        val uri = try { URI(s) } catch (_: Exception) { return Result.Invalid("Not a valid URL") }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "https" && !(allowHttp && scheme == "http"))
            return Result.Invalid(if (scheme == "http") "Plain HTTP is not allowed in this build; use https://" else "Must start with https://")
        if (uri.host.isNullOrEmpty()) return Result.Invalid("Address has no host")
        if (uri.userInfo != null || uri.query != null || uri.fragment != null) return Result.Invalid("Enter just the server address, nothing else")
        val path = uri.path?.trimEnd('/').orEmpty()
        return Result.Ok("$scheme://${uri.host}${if (uri.port != -1) ":${uri.port}" else ""}$path")
    }
}
