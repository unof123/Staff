package com.multikore.korepay.staff

/** Luhn check-digit validation for a 15-digit IMEI, matching the server's validation exactly. */
object Imei {
    fun isValid(s: String): Boolean {
        if (!Regex("^[0-9]{15}$").matches(s)) return false
        var sum = 0
        for (i in 0 until 15) {
            var d = s[14 - i] - '0'
            if (i % 2 == 1) { d *= 2; if (d > 9) d -= 9 }
            sum += d
        }
        return sum % 10 == 0
    }
}
