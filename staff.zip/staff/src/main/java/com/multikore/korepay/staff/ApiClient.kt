package com.multikore.korepay.staff

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.net.ssl.SSLException
import org.json.JSONException
import org.json.JSONObject

class ApiException(val status: Int, val code: String, message: String) : Exception(message) {
    val isNetwork get() = status == 0
}

/** JSON + multipart HTTPS client for the KorePay admin API, authenticated with the staff bearer token. */
class ApiClient(private val baseUrl: String, private val token: String?) {

    fun get(path: String): JSONObject = request("GET", path, null, null)
    fun post(path: String, body: JSONObject): JSONObject = request("POST", path, "application/json; charset=utf-8", body.toString().toByteArray(Charsets.UTF_8))

    /** Uploads one file as multipart/form-data with a single extra text field "kind". */
    fun uploadDocument(path: String, kind: String, bytes: ByteArray, filename: String, contentType: String): JSONObject {
        val boundary = "KorePayStaff-" + UUID.randomUUID().toString()
        val out = ByteArrayOutputStream()
        fun part(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
        part("--$boundary\r\nContent-Disposition: form-data; name=\"kind\"\r\n\r\n$kind\r\n")
        part("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$filename\"\r\nContent-Type: $contentType\r\n\r\n")
        out.write(bytes)
        part("\r\n--$boundary--\r\n")
        return request("POST", path, "multipart/form-data; boundary=$boundary", out.toByteArray())
    }

    private fun request(method: String, path: String, contentType: String?, body: ByteArray?): JSONObject {
        val conn = try { URL(baseUrl + path).openConnection() as HttpURLConnection } catch (e: IOException) {
            throw ApiException(0, "network", "Invalid server address")
        }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("Accept", "application/json")
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                conn.doOutput = true
                contentType?.let { conn.setRequestProperty("Content-Type", it) }
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.let { readLimited(it) } ?: ""
            if (code in 300..399) throw ApiException(code, "redirect", "The server redirected the request. Check the server address in Settings.")
            val json = try { if (text.isBlank()) JSONObject() else JSONObject(text) } catch (_: JSONException) { JSONObject() }
            if (code !in 200..299) {
                val err = json.optJSONObject("error")
                throw ApiException(code, err?.optString("code")?.ifEmpty { null } ?: "http_$code", err?.optString("message")?.ifEmpty { null } ?: "Server returned HTTP $code")
            }
            return json
        } catch (e: ApiException) {
            throw e
        } catch (e: SSLException) {
            throw ApiException(0, "tls", "Secure connection failed (${e.javaClass.simpleName}). Check the device date/time.")
        } catch (e: IOException) {
            throw ApiException(0, "network", "Cannot reach the server (${e.javaClass.simpleName})")
        } finally {
            conn.disconnect()
        }
    }

    private fun readLimited(s: InputStream, max: Int = 1_000_000): String {
        val out = ByteArrayOutputStream(); val buf = ByteArray(8192)
        s.use { while (true) { val n = it.read(buf); if (n < 0) break; out.write(buf, 0, n); if (out.size() > max) throw IOException("response too large") } }
        return out.toString("UTF-8")
    }
}

/** Builds a client for the signed-in staff member, or throws if not signed in / server not set. */
fun apiFor(c: android.content.Context): ApiClient {
    val url = Session.serverUrl(c) ?: throw ApiException(0, "no_server", "Server address is not set. Open Settings first.")
    val token = Session.token(c) ?: throw ApiException(401, "signed_out", "Signed out. Please sign in again.")
    return ApiClient(url, token)
}
