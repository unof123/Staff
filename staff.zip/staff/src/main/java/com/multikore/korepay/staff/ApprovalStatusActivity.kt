package com.multikore.korepay.staff

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

/** Keeps QR enrollment behind the server-side Admin approval gate. */
class ApprovalStatusActivity : AppCompatActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var check: Button
    private var approved = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "Application submitted"; textSize = 22f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "Your application is waiting for Admin review. The enrollment QR will appear only after approval."; textSize = 15f; setPadding(0, 16, 0, 24) })
        status = TextView(this).apply { text = "Status: checking…"; textSize = 16f }
        root.addView(status)
        check = Button(this).apply { text = "Check approval status"; setOnClickListener { checkStatus() } }
        root.addView(check)
        root.addView(Button(this).apply { text = "Back to Home"; setOnClickListener { WizardState.reset(); startActivity(Intent(this@ApprovalStatusActivity, HomeActivity::class.java)); finish() } })
        setContentView(root)
        checkStatus()
    }

    private fun checkStatus() {
        val id = WizardState.customerId ?: run { status.text = "No current application found. Start a new application."; return }
        check.isEnabled = false; status.text = "Checking with server…"
        io.execute {
            try {
                val res = apiFor(this).get("/api/v1/admin/customers/$id")
                val c = res.getJSONObject("customer")
                val state = c.optString("approval_status", "pending")
                val message = when (state) {
                    "approved" -> "Approved ✓ — creating enrollment QR…"
                    "rejected" -> "Rejected: ${c.optString("approval_reason", "Please contact Admin for details.")}"
                    else -> "Pending Admin approval. QR is not available yet."
                }
                runOnUiThread {
                    status.text = message
                    check.isEnabled = true
                    if (state == "approved" && !approved) {
                        approved = true
                        startActivity(Intent(this, EnrollQrActivity::class.java))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not check status: ${e.message ?: "server error"}"; check.isEnabled = true }
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
