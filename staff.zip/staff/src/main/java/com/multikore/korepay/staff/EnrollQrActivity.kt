package com.multikore.korepay.staff

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.multikore.korepay.staff.databinding.ActivityEnrollQrBinding
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Creates the enrollment QR code on the server and renders it. This is the genuine Android
 * Enterprise provisioning payload (component name, signed-APK download URL + checksum, server
 * URL, one-time token, command key) -- the same thing KorePay Admin produces, generated here so a
 * field agent never has to go back to a desktop. It must be scanned by the CUSTOMER'S NEW phone's
 * own setup wizard (6 taps on the Welcome screen), not by this app's camera.
 */
class EnrollQrActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEnrollQrBinding
    private val io = Executors.newSingleThreadExecutor()
    private var enrollmentId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEnrollQrBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (WizardState.customerId == null) { finish(); return }

        binding.btnDone.setOnClickListener { WizardState.reset(); startActivity(Intent(this, HomeActivity::class.java)); finish() }
        binding.btnCheckStatus.setOnClickListener { checkStatus() }
        createEnrollment()
    }

    private fun createEnrollment() {
        binding.tvStatus.text = "Creating enrollment…"
        io.execute {
            try {
                val body = JSONObject().put("label", WizardState.customerLabel ?: "KorePay customer phone").put("customer_id", WizardState.customerId)
                val res = apiFor(this).post("/api/v1/admin/enrollments", body)
                enrollmentId = res.getJSONObject("enrollment").getString("id")
                val qrText = res.getString("qr_text")
                val expires = res.getJSONObject("enrollment").optString("expires_at")
                val warnings = res.optJSONArray("warnings")
                val bmp = renderQr(qrText)
                runOnUiThread {
                    binding.imgQr.setImageBitmap(bmp)
                    binding.tvStatus.text = "Pending — not yet scanned"
                    binding.tvExpiry.text = "Expires: $expires" + (warnings?.let { if (it.length() > 0) "\n⚠ " + it.getString(0) else "" } ?: "")
                }
            } catch (e: ApiException) {
                runOnUiThread {
                    binding.tvStatus.text = "Could not create the QR code"
                    val extra = when (e.code) {
                        "enrollment_not_configured" -> "\nThe server is not fully configured for QR enrollment yet. Ask an administrator to check System status."
                        "conflict" -> "\nThis customer application may still be awaiting Admin approval. Ask Admin to review it, then try again."
                        else -> ""
                    }
                    Toast.makeText(this, (e.message ?: "Error") + extra, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun renderQr(text: String): Bitmap {
        val hints = mapOf(EncodeHintType.MARGIN to 1)
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 900, 900, hints)
        val bmp = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
        for (x in 0 until matrix.width) for (y in 0 until matrix.height) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        return bmp
    }

    private fun checkStatus() {
        val id = enrollmentId ?: return
        binding.btnCheckStatus.isEnabled = false
        io.execute {
            try {
                val devices = apiFor(this).get("/api/v1/admin/devices?customer_id=${WizardState.customerId}&status=enrolled&page_size=5")
                val list = devices.getJSONArray("items")
                if (list.length() > 0) {
                    val d = list.getJSONObject(0)
                    runOnUiThread { binding.tvStatus.text = "Enrolled ✓ — ${d.optString("label")} (${if (d.optBoolean("is_device_owner")) "Device Owner confirmed" else "not yet Device Owner"})"; binding.btnCheckStatus.isEnabled = true }
                    return@execute
                }
                val enrollments = apiFor(this).get("/api/v1/admin/enrollments?page_size=50")
                val items = enrollments.getJSONArray("items")
                var status = "Pending — not yet scanned"
                for (i in 0 until items.length()) {
                    val o = items.getJSONObject(i)
                    if (o.getString("id") == id) {
                        status = when (o.optString("status")) {
                            "used" -> "Scanned — waiting for the phone to finish setup and register"
                            "expired" -> "Failed: the QR code expired before it was used. Generate a new one."
                            "revoked" -> "Failed: this QR code was revoked."
                            else -> "Pending — not yet scanned"
                        }
                        break
                    }
                }
                runOnUiThread { binding.tvStatus.text = status; binding.btnCheckStatus.isEnabled = true }
            } catch (e: ApiException) {
                runOnUiThread { binding.btnCheckStatus.isEnabled = true; Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
