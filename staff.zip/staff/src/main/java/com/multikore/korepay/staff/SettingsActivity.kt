package com.multikore.korepay.staff

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.multikore.korepay.staff.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.etServer.setText(Session.serverUrl(this) ?: "")
        binding.btnSave.setOnClickListener {
            when (val r = ServerUrl.validate(binding.etServer.text.toString(), BuildConfig.ALLOW_HTTP)) {
                is ServerUrl.Result.Ok -> { Session.setServerUrl(this, r.url); finish() }
                is ServerUrl.Result.Invalid -> { binding.tvError.text = r.reason; binding.tvError.visibility = View.VISIBLE }
            }
        }
    }
}
