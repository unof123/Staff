package com.multikore.korepay.staff

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.multikore.korepay.staff.databinding.ActivityCustomerFormBinding
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class CustomerFormActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCustomerFormBinding
    private val io = Executors.newSingleThreadExecutor()
    private var pendingKind: String = "cnic_front"
    private var pendingUri: Uri? = null
    private var frontUri: Uri? = null
    private var backUri: Uri? = null
    private val uploadedCnicKinds = mutableSetOf<String>()

    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCnicCamera(pendingKind) else showError("Camera permission is needed to capture the CNIC.")
    }
    private val takeCnicPhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingUri
        if (ok && uri != null) {
            if (pendingKind == "cnic_front") { frontUri = uri; binding.tvFrontStatus.text = "Front captured — reading text…" }
            else { backUri = uri; binding.tvBackStatus.text = "Back captured — reading address…" }
            runOcr(uri, pendingKind)
        } else if (pendingKind == "cnic_front") binding.tvFrontStatus.text = "Front photo not captured" else binding.tvBackStatus.text = "Back photo not captured"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomerFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnNext.setOnClickListener { submit() }
        binding.btnScanCnic.setOnClickListener { capture("cnic_front") }
        binding.btnScanBack.setOnClickListener { capture("cnic_back") }
    }

    private fun capture(kind: String) {
        pendingKind = kind
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestCamera.launch(Manifest.permission.CAMERA)
        else launchCnicCamera(kind)
    }

    private fun launchCnicCamera(kind: String) {
        pendingKind = kind
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        val file = File(dir, "$kind-${System.currentTimeMillis()}.jpg")
        pendingUri = FileProvider.getUriForFile(this, "com.multikore.korepay.staff.fileprovider", file)
        takeCnicPhoto.launch(pendingUri!!)
    }

    private fun normalizeDigits(s: String) = s.map { ch -> when (ch) { in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar(); in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar(); else -> ch } }.joinToString("")

    private fun runOcr(uri: Uri, kind: String) {
        val status = if (kind == "cnic_front") binding.tvFrontStatus else binding.tvBackStatus
        status.text = "Reading text on this phone…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener { result ->
                    val text = normalizeDigits(result.text)
                    if (kind == "cnic_front") parseFront(text) else parseBack(text)
                    status.text = if (text.isBlank()) "No text found. Enter details manually." else "OCR finished. Verify/correct every field against the original CNIC."
                }
                .addOnFailureListener { status.text = "OCR failed. You can enter details manually." }
        } catch (_: Exception) { status.text = "Could not read photo. Enter details manually." }
    }

    private fun parseFront(text: String) {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val cnic = Regex("(?<!\\d)(\\d{5})[- ]?(\\d{7})[- ]?(\\d)(?!\\d)").find(text)
            ?: Regex("(?<!\\d)(\\d{13})(?!\\d)").find(text)
        cnic?.value?.filter { it.isDigit() }?.takeIf { it.length == 13 }?.let { binding.etCnicNumber.setText(it) }
        fun afterLabel(vararg labels: String): String? {
            val i = lines.indexOfFirst { line -> labels.any { line.contains(it, true) } && !(labels.any { it.equals("Name", true) } && line.contains("Father", true)) }
            if (i < 0) return null
            val same = lines[i].substringAfter(':', "").trim()
            if (same.length > 2) return same
            return lines.getOrNull(i + 1)?.takeIf { it.length > 2 }
        }
        afterLabel("Name", "نام")?.let { if (binding.etName.text.isNullOrBlank()) binding.etName.setText(it.substringAfter(':').trim()) }
        afterLabel("Father", "Husband", "والد")?.let { if (binding.etFatherName.text.isNullOrBlank()) binding.etFatherName.setText(it.substringAfter(':').trim()) }
        val dates = Regex("(?<!\\d)(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})(?!\\d)").findAll(text).map { it.groupValues.drop(1) }.toList()
        fun dateIso(a: List<String>): String? = if (a.size == 3) runCatching {
            if (a[0].length == 4) "%04d-%02d-%02d".format(a[0].toInt(), a[1].toInt(), a[2].toInt())
            else "%04d-%02d-%02d".format(a[2].toInt(), a[1].toInt(), a[0].toInt())
        }.getOrNull() else null
        if (dates.isNotEmpty()) dateIso(dates[0])?.let { binding.etIssueDate.setText(it) }
        if (dates.size > 1) dateIso(dates[1])?.let { binding.etExpiryDate.setText(it) }
    }

    private fun parseBack(text: String) {
        val lines = text.lines().map { it.trim() }.filter { it.length > 4 }
        val addressLines = lines.filterNot { it.contains("signature", true) || it.contains("address", true) || it.contains("holder", true) || it.contains("emergency", true) }
        if (addressLines.isNotEmpty()) {
            val candidate = addressLines.takeLast(4).joinToString(", ").take(500)
            if (binding.etTempAddress.text.isNullOrBlank()) binding.etTempAddress.setText(candidate)
            if (binding.etPermAddress.text.isNullOrBlank()) binding.etPermAddress.setText(candidate)
        }
        if (binding.etTempAddress.text.isNullOrBlank()) binding.etTempAddress.hint = "Temporary address * (OCR did not detect it; enter manually)"
    }

    private fun showError(m: String) { binding.tvError.text = m; binding.tvError.visibility = View.VISIBLE }
    private fun value(v: android.widget.EditText) = v.text.toString().trim()

    private fun submit() {
        val name = value(binding.etName); val father = value(binding.etFatherName)
        val cnic = value(binding.etCnicNumber).filter { it.isDigit() }
        val phone = value(binding.etPhone); val issue = value(binding.etIssueDate); val expiry = value(binding.etExpiryDate)
        val temp = value(binding.etTempAddress); val permanent = value(binding.etPermAddress)
        val refName = value(binding.etRefName); val refPhone = value(binding.etRefPhone); val refAddress = value(binding.etRefAddress)
        val consentRef = value(binding.etConsentRef)
        if (frontUri == null || backUri == null) { showError("Capture both the front and back of the CNIC first."); return }
        if (name.length < 2 || father.length < 2) { showError("Enter the full customer name and father name."); return }
        if (cnic.length != 13) { showError("Enter/verify the complete 13-digit CNIC number."); return }
        val isoDate = Regex("^\\d{4}-\\d{2}-\\d{2}$")
        if (!isoDate.matches(issue) || !isoDate.matches(expiry)) { showError("Enter CNIC issue and expiry dates as YYYY-MM-DD."); return }
        if (phone.filter { it.isDigit() }.length < 7) { showError("Enter a valid customer mobile number."); return }
        if (temp.isBlank() || permanent.isBlank()) { showError("Temporary and permanent addresses are mandatory. Enter them manually if OCR could not read them."); return }
        if (refName.length < 2 || refPhone.filter { it.isDigit() }.length < 7 || refAddress.isBlank()) { showError("Complete reference name, mobile number, and address."); return }
        if (!binding.cbConsent.isChecked) { showError("Customer consent is required before continuing."); return }
        if (consentRef.isBlank()) { showError("Enter the contract/agreement reference."); return }

        binding.btnNext.isEnabled = false; binding.tvError.visibility = View.GONE
        io.execute {
            try {
                val body = JSONObject().put("full_name", name).put("phone", phone).put("address", permanent)
                    .put("national_id_last4", cnic.takeLast(4)).put("national_id_number", cnic)
                    .put("father_name", father).put("national_id_issue_date", issue).put("national_id_expiry_date", expiry)
                    .put("temporary_address", temp).put("permanent_address", permanent)
                    .put("reference_name", refName).put("reference_phone", refPhone).put("reference_address", refAddress)
                    .put("consent_at", java.time.Instant.now().toString()).put("consent_reference", consentRef)
                if (WizardState.customerId == null) {
                    val res = apiFor(this).post("/api/v1/admin/customers", body)
                    val customer = res.getJSONObject("customer")
                    WizardState.customerId = customer.getString("id")
                    WizardState.customerLabel = name
                }
                if (!uploadedCnicKinds.contains("cnic_front")) { uploadCapture("cnic_front", frontUri!!); uploadedCnicKinds.add("cnic_front") }
                if (!uploadedCnicKinds.contains("cnic_back")) { uploadCapture("cnic_back", backUri!!); uploadedCnicKinds.add("cnic_back") }
                runOnUiThread { startActivity(Intent(this, DocumentCaptureActivity::class.java)) }
            } catch (e: Exception) {
                runOnUiThread { binding.btnNext.isEnabled = true; showError(e.message ?: "Could not save customer details") }
            }
        }
    }

    private fun uploadCapture(kind: String, uri: Uri) {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw ApiException(0, "photo_read", "Could not read $kind photo")
        if (bytes.size > 10 * 1024 * 1024) throw ApiException(413, "too_large", "$kind photo is too large")
        apiFor(this).uploadDocument("/api/v1/admin/customers/${WizardState.customerId}/documents", kind, bytes, "$kind.jpg", "image/jpeg")
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
