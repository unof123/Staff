package com.multikore.korepay.staff

/** "12,500" / "12500.50" -> integer minor units (paisa). No floating point, matching the server. */
object Money {
    fun toMinor(input: String): Int? {
        val s = input.replace(",", "").replace(" ", "")
        if (!Regex("^\\d{1,10}(\\.\\d{1,2})?$").matches(s)) return null
        val parts = s.split(".")
        val major = parts[0].toLong()
        val frac = (parts.getOrNull(1) ?: "").padEnd(2, '0')
        val total = major * 100 + frac.toLong()
        return if (total in 1..Int.MAX_VALUE.toLong()) total.toInt() else null
    }
}
