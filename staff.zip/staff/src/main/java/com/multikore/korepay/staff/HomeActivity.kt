package com.multikore.korepay.staff

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.multikore.korepay.staff.databinding.ActivityHomeBinding
import java.util.concurrent.Executors

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!Session.isSignedIn(this)) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }

        binding.tvWho.text = Session.name(this) ?: Session.email(this) ?: ""
        binding.tvRole.text = "Role: ${Session.role(this)?.replace('_', ' ') ?: ""}"

        binding.btnNewCustomer.setOnClickListener {
            WizardState.reset()
            startActivity(Intent(this, CustomerFormActivity::class.java))
        }
        binding.btnEnrollments.setOnClickListener { loadEnrollments() }
        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnLogout.setOnClickListener { signOut() }
    }

    override fun onResume() {
        super.onResume()
        loadEnrollments()
    }

    private fun loadEnrollments() {
        io.execute {
            try {
                val res = apiFor(this).get("/api/v1/admin/enrollments?page_size=10")
                val items = res.getJSONArray("items")
                runOnUiThread {
                    binding.enrollmentList.removeAllViews()
                    if (items.length() == 0) {
                        binding.enrollmentList.addView(TextView(this).apply { text = "No enrollments yet." })
                    }
                    for (i in 0 until items.length()) {
                        val o = items.getJSONObject(i)
                        binding.enrollmentList.addView(TextView(this).apply {
                            text = "${o.optString("label")} — ${o.optString("status")}" + (if (o.optString("device_label", "").isNotEmpty()) " (${o.optString("device_label")})" else "")
                            setPadding(0, 10, 0, 10)
                        })
                    }
                }
            } catch (e: ApiException) {
                runOnUiThread { Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun signOut() {
        io.execute {
            try { apiFor(this).post("/api/v1/admin/staff-auth/logout", org.json.JSONObject()) } catch (_: Exception) { }
            Session.clear(this)
            runOnUiThread { startActivity(Intent(this, LoginActivity::class.java)); finish() }
        }
    }

    override fun onDestroy() { super.onDestroy(); io.shutdown() }
}
