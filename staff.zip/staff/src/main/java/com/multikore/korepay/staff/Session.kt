package com.multikore.korepay.staff

import android.content.Context

/** Signed-in staff member's identity, permissions, and the server address this app was set up with. */
object Session {
    private const val K_TOKEN = "staff_token"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("staff_session", Context.MODE_PRIVATE)

    fun serverUrl(c: Context): String? = p(c).getString("server_url", "https://api.korepay.pk")
    fun setServerUrl(c: Context, url: String) = p(c).edit().putString("server_url", url).apply()

    fun token(c: Context): String? = SecureStore.get(c, K_TOKEN)
    fun isSignedIn(c: Context) = token(c) != null

    fun name(c: Context): String? = p(c).getString("name", null)
    fun email(c: Context): String? = p(c).getString("email", null)
    fun role(c: Context): String? = p(c).getString("role", null)
    fun permissions(c: Context): Set<String> = p(c).getStringSet("permissions", emptySet()) ?: emptySet()
    fun can(c: Context, perm: String) = permissions(c).contains(perm)

    fun save(c: Context, token: String, name: String, email: String, role: String, permissions: List<String>): Boolean {
        if (!SecureStore.put(c, K_TOKEN, token)) return false
        p(c).edit().putString("name", name).putString("email", email).putString("role", role).putStringSet("permissions", permissions.toSet()).apply()
        return true
    }

    fun clear(c: Context) {
        SecureStore.remove(c, K_TOKEN)
        p(c).edit().remove("name").remove("email").remove("role").remove("permissions").apply()
    }
}

/** The customer/phone/plan being registered right now. Cleared when a registration finishes or is abandoned. */
object WizardState {
    var customerId: String? = null
    var customerLabel: String? = null
    var planId: String? = null
    fun reset() { customerId = null; customerLabel = null; planId = null }
}
